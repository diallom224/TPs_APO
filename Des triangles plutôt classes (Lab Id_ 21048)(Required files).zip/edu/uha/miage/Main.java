/*
 * @author : Yvan Maillot (yvan.maillot@uha.fr)
 */
package edu.uha.miage;

/**
 * @author yvan
 */
public class Main {

    public static void main(String[] args) {
        // Ecrire ici vos tests personnels
        System.out.println("Ecrire vos tests personnels dans edu.uha.miage.Main");
    }
}
